Mon, 24 Aug 2009  01:38


Each subdirectory here contains a SampleUrls.txt and an
IIRF.ini file. 

Each pair of files is intended to illustrate or test a
feature. Check the comments in the IsapiRewrite4.ini file for
details. 

To run these tests, run the TestDriver.exe with the -d switch.
Example:

  TestDriver -d tests\IterationLimit



#define DEBUGTRACE  0

/*

  IirfLogging.c

  Ionic's Isapi Rewrite Filter [IIRF]

  ISAPI Filter that does  URL-rewriting.
  Inspired by Apache's mod_rewrite .
  Implemented in C, does not use MFC.

  Copyright (c) Dino Chiesa, 2005-2010.  All rights reserved.

  ==================================================================

  Licensed under the MS Public License.
  http://opensource.org/licenses/ms-pl.html

  or, see Rewriter.c for the details of the license.

  Last saved:
  Time-stamp: <2010-May-29 17:35:55>

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <share.h>     // for _SH_DENYWR menmonic

#include <WTypes.h>    // for DWORD, etc

#include <WinNT.h>     // for event log

#include "Iirf.h"


// extern decls
extern void Iirf_EmitEventLogEventX( WORD infoType, DWORD dwEventId, LPTSTR msg2, LPTSTR format, ... );  // Utils.c
extern CRITICAL_SECTION  gcsFilterConfig;
extern CRITICAL_SECTION  gcsLogFileList;
extern IirfServerConfig * gFilterConfig;
extern LogFileEntry * gLogFileList;
extern char * gIirfVersion;
extern char * gIirfBuildSig;  // timestamp generated at compile-time, inserted into a separate module





// forward decls
void LogMessage( IirfVdirConfig * cfg, int MsgLevel, const char * format, ... );



#if DEBUGTRACE
static FILE * gLog = NULL;
static char * DebugLogFile = "c:\\inetpub\\iirfLogs\\IIRF-Debug.log";

void VTRACE(const char * format, va_list argp)
{
    char * MessageBuffer;
    int len;
    if (gLog == NULL)
    {
        // if testing (like TestDriver.exe) then output is stdout.  Else, use a file.
                gLog= (gFilterConfig == NULL || !gFilterConfig->Testing)
                        ? _fsopen(DebugLogFile,"a+", _SH_DENYNO )
                        : stdout ;
        fprintf(gLog,"\n-------------------------------------------------------\n");
    }
    len = _vscprintf( format, argp ) + 1; // _vscprintf doesn't count terminating '\0'
    MessageBuffer= malloc( len * sizeof(char) );
    vsprintf_s( MessageBuffer, len, format, argp );
    fprintf(gLog,"%s\n",MessageBuffer);
    free( MessageBuffer );

    fflush(gLog);
}


void TRACE( const char * format, ... )
{
    va_list argp;
    va_start( argp, format );
    VTRACE(format, argp);
    va_end(argp);
}

void CacheLogMessage( int level, const char * format, ... )
{
    va_list argp;
    va_start( argp, format );
    VTRACE(format, argp);
    va_end(argp);
}


#else


/*
 * CacheLogMessage
 *
 * Caches the given message until such time as a logfile is available.
 * Generally this is used for log messages at filter startup, but
 * before any site configuration is loaded. The messages are cached
 * until they are emitted into the logfile of the first site.
 *
 */
void CacheLogMessage( int level, const char * format, ... )
{
    va_list args;
    CachedLogMessage * Msg = (CachedLogMessage *) malloc(sizeof(CachedLogMessage));
    int len;
    va_start( args, format );
    len = _vscprintf( format, args ) + 1; // _vscprintf doesn't count terminating '\0'
    Msg->Data= malloc( len * sizeof(char) );
    vsprintf_s( Msg->Data, len, format, args );
    Msg->Next = NULL;
    Msg->Level = level;

    EnterCriticalSection(&gcsFilterConfig);

    // cache it:
    if (gFilterConfig->MsgCache==NULL)
        gFilterConfig->MsgCache= Msg;
    else {
        CachedLogMessage * c= gFilterConfig->MsgCache;
        while (c->Next != NULL) c= c->Next;
        c->Next = Msg;
    }

    LeaveCriticalSection(&gcsFilterConfig);
}

void TRACE(const char * format, ...)
{
}


#endif




void EmitCachedMessages( IirfVdirConfig * cfg, int allOneLevel)
{
    if (gFilterConfig->MsgCache)
    {
        int level;
        CachedLogMessage * currentMsg;
        CachedLogMessage * previousMsg;
        EnterCriticalSection(&gcsFilterConfig);
        currentMsg = gFilterConfig->MsgCache;
        gFilterConfig->MsgCache= NULL; // prevent infinite recursion
        while (currentMsg != NULL) {
            level = allOneLevel ? 1 : currentMsg->Level;
            LogMessage(cfg, level, "Cached: %s", currentMsg->Data);
            previousMsg = currentMsg;
            currentMsg= currentMsg->Next;
            // clean up as we go
            free(previousMsg->Data);
            free(previousMsg);
        }
        LeaveCriticalSection(&gcsFilterConfig);
    }
}



static const char * logFormat = "%s - %5d - %s\n";
static const char * logFormat_NoNewline = "%s - %5d - %s";


void LogMessage( IirfVdirConfig * cfg, int MsgLevel, const char * format, ... )
{

#if DEBUGTRACE
    time_t t;
    char TimeBuffer[26] ;
    va_list args;
    int len;
    char * MessageBuffer;

    if (gLog == NULL)
    {
        gLog= _fsopen(DebugLogFile, "w", _SH_DENYWR );
    }

    time(&t);
    ctime_s(TimeBuffer,26,&t);
    // 0123456789012345678901234 5
    // Wed Jan 02 02:03:55 1980\n\0
    TimeBuffer[24]=0; // null out final newline

    va_start( args, format );
    len = _vscprintf( format, args ) + 1; // _vscprintf doesn't count terminating '\0'
    MessageBuffer = malloc( len * sizeof(char) );
    vsprintf_s( MessageBuffer, len, format, args );
    fprintf(gLog,"%s - %s\n", TimeBuffer,MessageBuffer);
    free( MessageBuffer );

    fflush(gLog);

#else

    if (cfg==NULL) return;

    if (cfg->LogLevel >= MsgLevel) {

        if (cfg->pLogFile!=NULL && cfg->pLogFile->LogFile!=NULL) {
            const char * format1;
            time_t t;
            char TimeBuffer[26] ;
            va_list args;
            int len;
            char * MessageBuffer;
            int r;

            if (MsgLevel > 0 && gFilterConfig->MsgCache) EmitCachedMessages(cfg, 0);

            time(&t);
            ctime_s(TimeBuffer,26,&t);
            // 0123456789012345678901234 5
            // Wed Jan 02 02:03:55 1980\n\0
            TimeBuffer[19]=0; // terminate before year and newline
            va_start( args, format );
            len = _vscprintf( format, args ) + 1; // _vscprintf doesn't count terminating '\0'
            MessageBuffer = malloc( len * sizeof(char) );
            r= vsprintf_s( MessageBuffer, len, format, args );
            format1 = (MessageBuffer[len-2]=='\n')?logFormat_NoNewline : logFormat;
            fprintf(cfg->pLogFile->LogFile, format1, TimeBuffer, GetCurrentThreadId(), (r!=-1)?MessageBuffer:format);
            free( MessageBuffer );
            fflush(cfg->pLogFile->LogFile);
        }
    }

#endif

}



void ReleaseLogFile(LogFileEntry *e)
{
    CRITICAL_SECTION *pCS;
    boolean destroyed= FALSE;
    if (e== NULL) return;

    EnterCriticalSection(e->pCS);
    pCS= e->pCS;
    e->RefCount--;

    if (e->RefCount<= 0)
    {
        destroyed = TRUE;
        if (e->LogFileName)  free(e->LogFileName);
        free(e);
    }
    LeaveCriticalSection(pCS);
    if (destroyed)
    {
        DeleteCriticalSection(pCS);
        free(pCS);
    }
    return;
}







// http://www.codeplex.com/IIRF/WorkItem/View.aspx?WorkItemId=17002
void IirfInvalidParameterHandler(
    const wchar_t* wszExpression,
    const wchar_t* wszFunction,
    const wchar_t* wszFile,
    unsigned int line,
    uintptr_t pReserved)
{
    // We had a bad pointer, or something.  Log an event in the event log.
    Iirf_EmitEventLogEventX(EVENTLOG_WARNING_TYPE, IIRF_EVENT_INVALID_PARAM, NULL,
                       "Invalid Parameter: expression(%S) func(%S) file(%S) line(%d)",
                       wszExpression, wszFunction, wszFile, line);
}





LogFileEntry * NewLogFile(char *LogFileName)
{
    LogFileEntry * a= malloc(sizeof(LogFileEntry));
    char *actualLogfileName= (gFilterConfig->Testing) ? "CON":LogFileName;
    int n= Iirf_ConvertSizeTo32bits(strlen(LogFileName)+1);
    TRACE("NewLogFile: logfilename = '%s'", LogFileName);

    a->RefCount= 1;
    a->LogFileName = (char *) malloc(n * sizeof(char));
    strcpy_s(a->LogFileName, n, LogFileName);

    a->pCS= malloc(sizeof(CRITICAL_SECTION));
    InitializeCriticalSection(a->pCS);

    a->LogFile=  (gFilterConfig->Testing) ? stdout :
        //_fsopen(actualLogfileName,"w", _SH_DENYNO ) :
        _fsopen(actualLogfileName,"a", _SH_DENYWR );

    if (a->LogFile==NULL) {
        TRACE("NewLogFile: Could not open log file '%s' (error: %d), trying with 'w' flag.", actualLogfileName, GetLastError());
        a->LogFile= _fsopen(actualLogfileName, "w", _SH_DENYNO );
        if (a->LogFile==NULL) {
            TRACE("NewLogFile: 2nd try, Could not open log file '%s' (error: %d)", actualLogfileName, GetLastError());
            Iirf_EmitEventLogEventX(EVENTLOG_WARNING_TYPE, IIRF_EVENT_BAD_LOGFILE, NULL,
                               "IIRF: Could not open log file '%s' (error: %d)",
                               actualLogfileName, GetLastError());
        }
    }

    TRACE("NewLogFile: LogFile = 0x%08X", a->LogFile);
    a->Next = NULL;

    return a;
}





LogFileEntry * GetLogFile(IirfVdirConfig * cfg)
{
    LogFileEntry * current;
    LogFileEntry * previous;
    char * LogFileName = cfg->LogFileName;

    TRACE("GetLogFile");

    EnterCriticalSection(&gcsLogFileList);
    current = gLogFileList;
    // see if we can find a match in the stack:
    TRACE("GetLogFile: root= 0x%08X", current);
    while (current != NULL) {
        TRACE("GetLogFile: compare: '%s'  '%s'", current->LogFileName, LogFileName);
        if (strcmp(current->LogFileName, LogFileName)==0) {
            // increment the refcount, then return the pointer
            current->RefCount++;
            LeaveCriticalSection(&gcsLogFileList);
            // insert this entry into the given site config:
            EnterCriticalSection(cfg->pCS);
            cfg->pLogFile = current;
            LeaveCriticalSection(cfg->pCS);
            return current;
        }
        previous= current;
        current = current->Next;
        TRACE("GetLogFile: next= 0x%08X", current);
    }

    // Arriving here means there is no open file pointer available for
    // the given LogFileName.
    // So we create one, and insert it into the list.

    current= NewLogFile(LogFileName);
    TRACE("GetLogFile: new= 0x%08X", current);
    if (gLogFileList == NULL)
        gLogFileList= current;
    else {
        // insert into the linked list
        previous->Next = current;
    }

    LeaveCriticalSection(&gcsLogFileList);

    // insert this entry into the given site config:
    EnterCriticalSection(cfg->pCS);
    cfg->pLogFile = current;
    LeaveCriticalSection(cfg->pCS);

    // emit some introductory information when first opening a log file...
    LogMessage(cfg, 0, "-------------------------------------------------------");
    LogMessage(cfg, 0, "%s", gIirfVersion);
    LogMessage(cfg, 0, "IIRF was built on: %s", gIirfBuildSig);

    EmitCachedMessages(cfg, 0);

    LogMessage(cfg, 1, "GetLogFile: app:'%s'  new log:'%s'", cfg->ApplMdPath, cfg->LogFileName);

    return current;
}



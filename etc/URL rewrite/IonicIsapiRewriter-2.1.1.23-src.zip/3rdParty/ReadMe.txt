Attention

This directory contains Third Party code,
specifically the PCRE library.

IIRF depends on PCRE.

The binary IIRF release statically links to the PCRE library.
The source IIRF release ships the static PCRE library.

PCRE is available under a distinct license from that
for IIRF.

Learn more about PCRE at http://www.pcre.org

==================================================================

Tue, 06 Apr 2010  08:50

To building PCRE v8.02 from source, for use with IIRF:

Pre-requisites: cmake.  Get

Get cmake from http://www.cmake.org.

CMake is a makefile configurator.  It generates makefiles for use by
various make utilities.  One of the kinds of makefiles it generates is
Visual Studio solution and .vcproj files.  Use cmake to build
a VS2008-compatible SLN for PCRE.


1. put cmake on path

2. extract PCRE source to c:\pcre-8.02\src

3. create a build dir:  c:\pcre-8.02\build-x86

4. run cmake-gui.exe

5. Specify locations of src + build from steps 2 & 3 above

6. Click "Configure"

7. Click the "Advanced" button.

    - Change all /MD to MT and /MDd to MTd .
    - remove all the standard libraries  (kernel32.lib, shell32.lib,
      etc.  all are unnecessary for PCRE)

8. Click "Configure" again

9. Click "Generate"

10. exit cmake, go to the build directory, run:

    msbuild PCRE.SLN /p:Configuration=Release

    Find the build products in the Release directory

done.


Then copy these files to the 3rdparty dir for IIRF:

    build\pcre.h
    build\Release\pcre.lib




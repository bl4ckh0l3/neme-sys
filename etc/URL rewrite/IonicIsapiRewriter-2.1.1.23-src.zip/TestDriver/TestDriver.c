/*
 * TestDriver.c
 *
 * Test driver module for the Isapi Rewrite filter.
 * This module links to the ISAPI filter DLL, and drives it.
 * This permits testing of the RewriteRules against a specific set of URLs,
 * from the command line, without needing to configure the ISAPI filter to IIS.
 * Output is sent to the console.
 *
 * Use this app to verify that the rewrite rules you have
 * authored are working as desired.
 *
 * ==================================================================
 *
 * License
 * ---------------------------------
 *
 * Ionic's ISAPI Rewrite Filter is an add-on to IIS that can
 * rewrite URLs.  IIRF and its documentation is distributed under
 * the Microsoft Permissive License, spelled out below.
 *
 * IIRF depends upon PCRE, which is licensed independently and
 * separately.  Consult the License.pcre.txt file for details.
 *
 *
 * --------------------------------------------
 * Microsoft Permissive License (Ms-PL)
 * Published: October 12, 2006
 *
 * This license governs use of the accompanying software. If you
 * use the software, you accept this license. If you do not accept
 * the license, do not use the software.
 *
 * 1. Definitions
 *
 * The terms "reproduce," "reproduction," "derivative works," and
 * "distribution" have the same meaning here as under
 * U.S. copyright law.
 *
 * A "contribution" is the original software, or any additions or
 * changes to the software.
 *
 * A "contributor" is any person that distributes its contribution
 * under this license.
 *
 * "Licensed patents" are a contributor's patent claims that read
 * directly on its contribution.
 *
 * 2. Grant of Rights
 *
 * (A) Copyright Grant- Subject to the terms of this license,
 * including the license conditions and limitations in section 3,
 * each contributor grants you a non-exclusive, worldwide,
 * royalty-free copyright license to reproduce its contribution,
 * prepare derivative works of its contribution, and distribute its
 * contribution or any derivative works that you create.
 *
 * (B) Patent Grant- Subject to the terms of this license,
 * including the license conditions and limitations in section 3,
 * each contributor grants you a non-exclusive, worldwide,
 * royalty-free license under its licensed patents to make, have
 * made, use, sell, offer for sale, import, and/or otherwise
 * dispose of its contribution in the software or derivative works
 * of the contribution in the software.
 *
 * 3. Conditions and Limitations
 *
 * (A) No Trademark License- This license does not grant you rights
 * to use any contributors' name, logo, or trademarks.
 *
 * (B) If you bring a patent claim against any contributor over
 * patents that you claim are infringed by the software, your
 * patent license from such contributor to the software ends
 * automatically.
 *
 * (C) If you distribute any portion of the software, you must
 * retain all copyright, patent, trademark, and attribution notices
 * that are present in the software.
 *
 * (D) If you distribute any portion of the software in source code
 * form, you may do so only under this license by including a
 * complete copy of this license with your distribution. If you
 * distribute any portion of the software in compiled or object
 * code form, you may only do so under a license that complies with
 * this license.
 *
 * (E) The software is licensed "as-is." You bear the risk of using
 * it. The contributors give no express warranties, guarantees or
 * conditions. You may have additional consumer rights under your
 * local laws which this license cannot change. To the extent
 * permitted under your local laws, the contributors exclude the
 * implied warranties of merchantability, fitness for a particular
 * purpose and non-infringement.
 * --------------------------------------------
 * end-of-license
 *
 * ==================================================================
 *
 *
 *
 * Copyright (c) Dino Chiesa and Microsoft Corporation, 2005 - 2009.
 * All rights reserved.
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include <WTypes.h>
#include <WinHttp.h>
#include <HttpFilt.h>

#include <pcre.h>

#include "IIRF.h"

#define DIR_SWITCH "-d"
#define TEST_URLS "SampleUrls.txt"


// externs
extern void LogMessage( IirfVdirConfig * cfg, int MsgLevel, const char * format, ... );    // IirfLogging.c
extern IirfVdirConfig * Iirf_IsapiFilterTestSetup(char * psz_iniDirName) ;


extern int Iirf_EvaluateRules(HTTP_FILTER_CONTEXT * pfc, char * subject, int depth, /* out */ char **result);

extern char * Iirf_GetVersion(void);
extern char * Iirf_GetBuildSig(void);



void Ascii2Wide(LPCSTR s, LPWSTR * w)
{
    DWORD len = Iirf_ConvertSizeTo32bits(strlen(s) + 1);
    (*w)= malloc(len * sizeof(wchar_t));

    ZeroMemory(*w, len*2);
    if (0 == MultiByteToWideChar(CP_ACP, 0, s, len, *w, len*2))
    {
        free(*w);
        *w = NULL;
    }
}


void Wide2Ascii(LPCWSTR w, LPSTR * s)
{
    int len2= Iirf_ConvertSizeTo32bits(lstrlenW(w));
    (*s) = (char*) malloc(len2+1);
    //fprintf(stderr,"U2A: alloc %d bytes\n", len2);
    ZeroMemory(*s, len2+1);
    if (0 == WideCharToMultiByte(CP_ACP, 0, w, len2, *s, len2, NULL, NULL))
    {
        // FAIL
        free(*s);
        *s = NULL;
    }
    else (*s)[len2]='\0';
}



BOOL CrackUrl(LPCSTR url, URL_COMPONENTS ** urlComponents)
{
    wchar_t * wUrl;
    char *s= NULL;

    (*urlComponents) = malloc(sizeof(URL_COMPONENTS));

    Ascii2Wide(url, &wUrl);

    // Initialize the URL_COMPONENTS structure.
    ZeroMemory(*urlComponents, sizeof(URL_COMPONENTS));

    (*urlComponents)->dwStructSize = sizeof(URL_COMPONENTS);

    // Set required component lengths to non-zero so that they are cracked.
    (*urlComponents)->dwSchemeLength    = -1;
    (*urlComponents)->dwHostNameLength  = -1;
    (*urlComponents)->dwUrlPathLength   = -1;
    (*urlComponents)->dwExtraInfoLength = -1;

    //printf("CrackUrl: %S. (len:=%d)", wUrl, wcslen(wUrl));

    if (!WinHttpCrackUrl( wUrl, Iirf_ConvertSizeTo32bits(wcslen(wUrl)), 0, (*urlComponents)))
    {
//         printf("CrackUrl: failed. (error=0x%08x  %d)",
//                GetLastError(), GetLastError());
        free(*urlComponents);
        free(wUrl);
        *urlComponents= NULL;
        return FALSE;
    }

    // must keep wUrl. The urlComponents structure points into this.
    // leak!
    // free(wUrl);
    return TRUE;
}


char * GetQueryString(char * url)
{
    URL_COMPONENTS * urlComponents;
    wchar_t tmp;
    char *s= NULL;

    if (!CrackUrl(url, &urlComponents))
    {
        if (GetLastError() == 12006)
        {
            // try again with prepended scheme and server
            char * t;
            int n = _scprintf( "%s%s", "http://www.example.com", url ) +1;
            t= malloc(n * sizeof(char));
            sprintf_s(t, n, "%s%s", "http://www.example.com", url );
            return GetQueryString(t);
        }
        printf("CrackUrl: failed. (error=0x%08x)", GetLastError());
        return NULL;
    }

    // The output urlComponents structure includes pointers that refer into the
    // existing LPWSTR, as well as lengths of the sections (scheme, server,
    // path, etc) of the URL.  The existing url string is unchanged, so if you want
    // to access a particular portion of the url (let's say, the scheme), you
    // need to terminate the string appropriately.

    //    tmp= urlComponents->lpszScheme[urlComponents->dwSchemeLength];
    //    urlComponents->lpszScheme[urlComponents->dwSchemeLength]= L'\0';
    //    printf("scheme: (0x%08x) %S\n", urlComponents->lpszScheme, urlComponents->lpszScheme);
    //    urlComponents->lpszScheme[urlComponents->dwSchemeLength]= tmp;
    //
    //    tmp= urlComponents->lpszHostName[urlComponents->dwHostNameLength];
    //    urlComponents->lpszHostName[urlComponents->dwHostNameLength]= L'\0';
    //    //printf("host: (0x%08x) %S\n", urlComponents->lpszHostName, urlComponents->lpszHostName);
    //    urlComponents->lpszHostName[urlComponents->dwHostNameLength]= tmp;
    //
    //    //printf("port: %d\n", urlComponents->nPort);
    //
    //    tmp= urlComponents->lpszUrlPath[urlComponents->dwUrlPathLength];
    //    urlComponents->lpszUrlPath[urlComponents->dwUrlPathLength]= L'\0';
    //    printf("urlpath: (0x%08x) %S\n", urlComponents->lpszUrlPath, urlComponents->lpszUrlPath);
    //    urlComponents->lpszUrlPath[urlComponents->dwUrlPathLength]= tmp;
    //

    if (urlComponents->lpszExtraInfo[0] == L'\0')
    {
        //no query string
        s= malloc(1);
        free(urlComponents);
        s[0]='\0';
        return s;
    }

    tmp= urlComponents->lpszExtraInfo[urlComponents->dwExtraInfoLength];
    urlComponents->lpszExtraInfo[urlComponents->dwExtraInfoLength]= L'\0';

    Wide2Ascii(urlComponents->lpszExtraInfo+1, &s);
    //printf("extrainfo: (0x%08x) %S\n", urlComponents->lpszExtraInfo, urlComponents->lpszExtraInfo);

    free(urlComponents);
    return s;
}


BOOL __stdcall TestGetServerVariable( HTTP_FILTER_CONTEXT *pfc,
                                      LPSTR lpszVariableName,
                                      LPVOID lpwBuffer,
                                      LPDWORD lpdwSize )
{
    if (_strnicmp(lpszVariableName, "QUERY_STRING", strlen("QUERY_STRING")) == 0)
    {
        char * s = GetQueryString(pfc->ServerContext);
        if (s== NULL) return FALSE;
        if (*lpdwSize == 0)
        {
            *lpdwSize = Iirf_ConvertSizeTo32bits(strlen(s));
        }
        else
        {
            strncpy_s( lpwBuffer, *lpdwSize, s, _TRUNCATE );
        }
        free(s);
    }
    else if (_strnicmp(lpszVariableName, "URL", strlen("URL")) == 0)
    {
        if (*lpdwSize == 0)
        {
            *lpdwSize = Iirf_ConvertSizeTo32bits(strlen(pfc->ServerContext));
        }
        else
        {
            strncpy_s( lpwBuffer, *lpdwSize, pfc->ServerContext, _TRUNCATE );
        }
    }
    return TRUE;
}

static char delims[]= " \n\r\t";

int ProcessUrls(IirfVdirConfig * cfg, char * SampleUrlsFile)
{
    FILE *infile;
    int lineNum=0;
    char line[2048];
    char resultBuf[2048];
    char *p1, *p2, *p3;
    char * resultString;
    char * actualResult ;
    int rc;
    int errorCount= 0;
    int expectedResultsProcessed= 0;
    int len, lineLen;
    boolean RecordOriginalUrl= FALSE;
    HTTP_FILTER_CONTEXT fc;
    IirfRequestContext ctx;
    //char * strtokContext= NULL;

    ctx.VdirConfig = cfg;
    fc.pFilterContext = &ctx;
    fc.GetServerVariable = TestGetServerVariable;

    printf("Processing URLs...(%s)\n\n", SampleUrlsFile);

    fopen_s(&infile, SampleUrlsFile, "r");
    if (infile==NULL) {
        printf("Cannot open Urls file '%s'\n", SampleUrlsFile);
        return -99;
    }

    while (TRUE) {
        lineNum++;
        if (fgets((char *)line, sizeof(line)-2, infile) == NULL) break;

        lineLen = Iirf_ConvertSizeTo32bits(strlen(line));
        line[lineLen+1] = '\0';     // add a 2nd terminator after end-of-line
        p1= line;

        while (isspace(*p1)) p1++;  // skip leading spaces
        if (*p1=='\0') continue;    // empty line
        if (*p1=='#') continue;     // comment line

        p2 = p1;
        // find the first space:
        while((*p2 != ' ')&&(*p2 != '\t')&&(*p2 != '\n')&&(*p2 != '\r')) p2++;
        *p2++='\0'; // terminate and advance

        // skip whitespace
        while((*p2 == ' ')||(*p2 == '\n')||(*p2 == '\r')||(*p2 == '\t')) p2++;

        if (*p2=='\0') {
            p2 = NULL;
        }
        else {
            expectedResultsProcessed++;
            p3 = p2 + strlen(p2) - 1;    // get the last char in the string (again)
            // trim trailing whitespace
            while((*p3 == ' ')||(*p3 == '\n')||(*p3 == '\r')||(*p3 == '\t')) *p3--='\0';
        }

#if NOT
        // must handle URLs with spaces - NOooooooooo!!
        p2= p1 + strlen(p1) - 1;    // get the last char in the string

        // trim trailing whitespace
        while((*p2 == ' ')||(*p2 == '\n')||(*p2 == '\r')||(*p2 == '\t')) *p2--='\0';

        // move back to first whitespace
        while((*p2 != ' ')&&(*p2 != '\t')) p2--;
        *p2 = '\0'; // terminate
        p2++;

        p3= p1 + strlen(p1) - 1;    // get the last char in the string (again)
        // trim trailing whitespace
        while((*p3 == ' ')||(*p3 == '\n')||(*p3 == '\r')||(*p3 == '\t')) *p3--='\0';
#endif

        len= Iirf_ConvertSizeTo32bits(strlen(p1));
//         //p2= p1 + len + 1; // get the expected result (maybe nothing)
//         if (p2 - line > lineLen) p2 = NULL;
//
//          if ((p2!=NULL) && (*p2 != '\0'))
//              expectedResultsProcessed++;


//         if ((p2!=NULL) && (*p2 != '\0'))
//         {
//             char *p3;
//             while((*p2 == ' ')||(*p2 == '\t')) p2++;       // skip leading spaces and TABs
//             p3= p2 + strlen(p2) - 1;
//             while((*p3 == ' ')||(*p3 == '\n')||(*p3 == '\r')||(*p3 == '\t')) *p3--='\0'; // trim trailing whitespace
//             expectedResultsProcessed++;
//         }

            len= Iirf_ConvertSizeTo32bits(strlen(p1));

//         while ((len>1) && (isspace(p1[len-1]))) {
//             p1[len-1]='\0';
//             len= strlen(p1);
//         }

        fc.ServerContext = p1;  // for TestGetServerVariable


        LogMessage(cfg, 1, "DoRewrites: Url: '%s'\n", p1);

        rc= Iirf_EvaluateRules(&fc, p1, 0, &resultString);

        if (rc == 0) {
            printf("\nNO REWRITE '%s' ==> --\n", p1);
            actualResult = "NO REWRITE";
        }
        else if (rc == 1) {
            printf("\nREWRITE '%s' ==> '%s'\n", p1, resultString);
            actualResult = resultString;
            //free(resultString);
        }
        else if (rc == 999) {
            printf("\nPROXY '%s' ==> '%s'\n", p1, resultString);
            actualResult = resultString;
        }
        else if (rc == 1200) {
            printf("\nSTATUS\n", p1);
            actualResult = "STATUS";
            //free(resultString);
        }
        else if (rc == 1403) {
            printf("\nFORBIDDEN '%s' \n", p1);
            actualResult = "FORBIDDEN";
            //free(resultString);
        }
        else if (rc == 1404) {
            printf("\nNOT FOUND '%s' \n", p1);
            actualResult = "NOT FOUND";
            //free(resultString);
        }
        else {
            rc-=1000;
            printf("\nREDIRECT %d '%s' ==> '%s'\n", rc, p1, resultString);
            sprintf_s(resultBuf, sizeof(resultBuf)/sizeof(resultBuf[0]),
                      "REDIRECT %d %s", rc, resultString);
            actualResult = resultBuf;
            //free(resultString);
        }

        if ( (p2!=NULL) && (*p2 != '\0'))
        {
            if (strcmp(p2, actualResult)==0)
                printf("OK\n");
            else {
                if ( (strcmp("NO REWRITE", actualResult)==0) &&
                     (strcmp(p1, p2) == 0))
                {
                    printf("OK\n");
                }
                else {
                    printf("ERROR expected(%s)\n        actual(%s)\n", p2, actualResult);
                    errorCount++;
                }
            }
        }

        //else
        //printf("\n'%s' ==>  I don't know??\n\n", p1);
    }

    if (expectedResultsProcessed != 0)
    {
        printf ("\n%d Errors in %d Total Trials\n", errorCount, expectedResultsProcessed);
    }

    fclose(infile);
    return errorCount;
}


void Usage(char *appname)
{
    printf("\nTestDriver.exe\n");
    printf("  tests urls and rules for IIRF.\n");
    printf("  This tool is linked with '%s'.\n", Iirf_GetVersion());
    printf("  The IIRF library was built '%s'\n\n", Iirf_GetBuildSig());
    printf("usage:\n");
    printf("  %s -d <directory>\n\n", appname);
    printf("  options:\n");
    printf("   -d <directory>    reads the ini file and '%s' from the \n",  TEST_URLS);
    printf("                     given directory.  (The default is to read them\n");
    printf("                     from the current working directory. \n\n\n");
}


int main(int argc, char **argv)
{
    char IniDir[_MAX_PATH];
    char FullpathUrls[_MAX_PATH];
    IirfVdirConfig * config;
    int errorCount = 0;

    if (argc==3)
    {
        if (_strnicmp(argv[1], DIR_SWITCH, strlen(DIR_SWITCH))==0) {
            strncpy_s(IniDir, MAX_PATH, argv[2], _MAX_PATH-1);
            sprintf_s(FullpathUrls, _MAX_PATH,"%s\\%s", argv[2], TEST_URLS);
        }
        else {
            Usage(argv[0]);
            return -1;
        }
    }
    /*     else if (argc==1){ */
    /*          strcpy_s(IniDir, _MAX_PATH, ".");  */
    /*  strcpy_s(FullpathUrls, _MAX_PATH, TEST_URLS); */
    /*     } */
    else {
        Usage(argv[0]);
        return -1;
    }

    printf("TestDriver: linked with '%s'.\n", Iirf_GetVersion());
    printf("TestDriver: The IIRF library was built on '%s'\n\n", Iirf_GetBuildSig());

    config= Iirf_IsapiFilterTestSetup(IniDir);

    errorCount = ProcessUrls(config, FullpathUrls);

    return errorCount;
}

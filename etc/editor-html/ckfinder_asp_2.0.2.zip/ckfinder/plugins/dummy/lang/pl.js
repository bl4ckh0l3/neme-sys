﻿/*
Copyright (c) 2003-2011, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKFinder.setPluginLang( 'dummy', 'pl',
		{
			dummy :
			{
				title : 'Testowe okienko',
				menuItem : 'Otwórz okienko dummy',
				typeText : 'Podaj jakiś tekst.'
			}
		});
